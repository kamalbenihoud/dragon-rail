---
layout: default
title: Accueil
---

<div class="hero">
  <h1 class="logo">🐉 DRAGON RAIL — <span>LE RÉSEAU QUI PROTÈGE<br>CEUX QUI VEILLENT</span></h1>
  <p class="intro">Ce qui est visible n’est qu’une illusion. Dragon Rail est ailleurs.</p>
</div>

<link rel="stylesheet" href="/assets/css/style.css">